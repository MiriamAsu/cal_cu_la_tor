let heading = document.getElementById('head');
let paragraph = document.getElementById('text');
const displayBox = document.querySelector('.display-box');
const calculatorBtns = document.getElementById('button');

heading.textContent = 'Simple Claculator';
paragraph.textContent = 'This is simple structured market calculator, mainly for business owners like; market women.';
heading.style.color = 'white';
paragraph.style.color = 'white';
